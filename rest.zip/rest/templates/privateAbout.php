<? require 'header.php' ?>

<p>This is a private About page.... only private users can see what we are really about!</p>

<? require 'footer.php' ?>