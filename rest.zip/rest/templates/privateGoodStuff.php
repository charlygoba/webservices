<? require 'header.php' ?>

<p>Good Stuff for members.</p>

<h1>I love lamp.</h1>

<? require 'footer.php' ?>