<? require 'header.php' ?>

<h2>You have logged out.</h2>

<p><a href="/">Back Home</a></p>

<? require 'footer.php' ?>