<? require 'header.php' ?>

<p>This is a sample app that allows you to logout or login on any page and stay on that page.</p>

<? require 'footer.php' ?>