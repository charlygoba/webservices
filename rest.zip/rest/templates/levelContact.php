<? require 'header.php' ?>

<p>This is a second level contact us page.</p>

<? require 'footer.php' ?>